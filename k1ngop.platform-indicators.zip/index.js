(function(t,n){
  Object.defineProperty(t,Symbol.toStringTag,{
    value:`Module`
  });
  var r=function(t){
    return t?.name||t?.default?.name||t?.type?.name||t?.default?.type?.name||t?.render?.name||t?.default?.render?.name
  },i=revenge.modules.finders.filters.createFilterGenerator(function([t],n,i){
    return r(i)===t
  },function([t]){
    return`withExactName(${t})`
  },1);
  function a(t){
    return typeof t?.default==`function`?{
      parent:t,key:`default`
    }:typeof t?.default?.type==`function`?{
      parent:t.default,key:`type`
    }:typeof t?.default?.render==`function`?{
      parent:t.default,key:`render`
    }:typeof t?.type==`function`?{
      parent:t,key:`type`
    }:typeof t?.render==`function`?{
      parent:t,key:`render`
    }:null
  }var o=revenge.jsonStorage.getJsonStorage(revenge.jsonStorage.pluginStoragePathFor(`k1ngop.platform-indicators`,`storage.json`),{
    default:{
      dmTopBar:!0,userList:!0,profileUsername:!0,removeDefaultMobile:!0,fallbackColors:!1,oldUserListIcons:!1
    },load:!0
  });
  function s(){
    var t=o.use()??o.cache,r=function(t,n){
      return o.set({
        [t]:n
      })
    };
    return(0,n.jsx)(revenge.react.ReactNative.ScrollView,{
      children:(0,n.jsxs)(revenge.discord.design.Design.TableRowGroup,{
        children:[(0,n.jsx)(revenge.discord.design.Design.TableSwitchRow,{
          label:`Show icons on the DM top bar`,value:t?.dmTopBar??!0,onValueChange:function(t){
            return r(`dmTopBar`,t)
          }
        }),(0,n.jsx)(revenge.discord.design.Design.TableSwitchRow,{
          label:`Show icons on the users and DMs list`,value:t?.userList??!0,onValueChange:function(t){
            return r(`userList`,t)
          }
        }),(0,n.jsx)(revenge.discord.design.Design.TableSwitchRow,{
          label:`Show icons on user profiles`,value:t?.profileUsername??!0,onValueChange:function(t){
            return r(`profileUsername`,t)
          }
        }),(0,n.jsx)(revenge.discord.design.Design.TableSwitchRow,{
          label:`Hide mobile status from the normal indicator`,value:t?.removeDefaultMobile??!0,onValueChange:function(t){
            return r(`removeDefaultMobile`,t)
          }
        }),(0,n.jsx)(revenge.discord.design.Design.TableSwitchRow,{
          label:`Theme compatibility mode`,value:t?.fallbackColors??!1,onValueChange:function(t){
            return r(`fallbackColors`,t)
          }
        }),(0,n.jsx)(revenge.discord.design.Design.TableSwitchRow,{
          label:`Old user list icon style`,subLabel:`Moves status indicators to the right`,value:t?.oldUserListIcons??!1,onValueChange:function(t){
            return r(`oldUserListIcons`,t)
          }
        })]
      })
    })
  }var c={
    online:`#23a55a`,dnd:`#f23f43`,idle:`#f0b232`,offline:`#80848e`
  },l={
    online:`STATUS_ONLINE`,dnd:`STATUS_DANGER`,idle:`STATUS_WARNING`,offline:`STATUS_OFFLINE`
  };
  function u(t,n=!1){
    var r=c[t]??c.offline;
    if(n)return r;
    try{
      var i=revenge.discord.common.tokens.Tokens?.colors?.[l[t]];
      if(typeof i==`string`)return i;
      if(typeof i?.resolve==`function`)return i.resolve()
    }catch{
    }return r
  }var d={
    desktop:{
      url:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAVFBMVEUAAACvv7+3u7+5u7+2ub+4u726vL65u765vL65vMG5u723ub23v7+3t7+6vL+4ur+6u765u764vL+4ur23t7+7vb+3ur25ur64ur+7u766ur6vr7/+1nXbAAAAHHRSTlMAEEB/UHDv/99fgIAgQJ+f7++fnyB/YN9vTz8QSaZf3QAAAI1JREFUeAHt1tUBwkAURNEXHZzg1n+d2Fc8u4OTOQXcyKqJ3ARh5C22qiQFYTC0khFIYyuYgDYthGagzQuhDLRFIYS7yBPuakLmSaF2CimkkEIKKfT8I5un0MdCT7v6LUFbFUIhaGsr2IAUWcl2B0K2t6pDVKttGR5P3BJvpxCnfdTMHVo9NaRQ1MpKRC5jHSw3VFQzIwAAAABJRU5ErkJggg==`,path:`PlatformIndicators/Desktop.png`
    },web:{
      url:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAQAAAD/5HvMAAADgklEQVR42u3a32vVdRzH8VdOv2NzGzM7bkp0E9F9RQSbOmK6groQpeugOzXJfnCW3YwgC4IyHCldrBmFELtQRxfK2MHp1sjVZRfBMSJFYu6cMUnOOZPz9Gb45uyc79fv5/tDvDiPv+DJh/fn8+HL56umpqbHFZsZ4hjjzJOnQJkyBfLMM87H7GWzHh16OcoVKgQpM8N79Cht7GaSVcJa5QK7lBZe5SpRzDCgpLGdH6gS3SRPKzm8xTJxFTmgJNDKtyRllFbFQxfTRLVCvSk6FR3b+J3onuRTlllvgUzk1YmVsyJJdPMN1bqkzmizM00cc1rDIP9SawpPrjhFPAf1AN1cotZJ940ezwKb1q33BLX2Kzx2sBwzZ7vWoYXvAVOkV2FxlqjuMMtBNqkBNpIDzI/h7ywnTsfIP5gquxUGV3EiB7zMPcxlPRwDOJITTgNmpx6GyZSDnqKAOa9g9LKKIzniA0yFbQrC+5B6UDf/Y44oCFdwdUPOGMfkgr8kyrg6Lmf0YUq0yw9DuLnBcTw5YwNFzB754RhmkYaUCH7BDMsPZzDDZFMM+gQzJj/8inlTYiS1oNcws/LD35jnJUtKPOgFzHX5YQmzdmCRTSXoGcyi/FDGtEqWlHhQG6YULsjTA4zg5iZf4CkAXrig25gtUowk+FwB2IpZDDfUz8pEWiUF4DnM9XDbfkiKl6QAvB5u248H38KMJBZ0FDMW7uo4qwbIJhQ0gcnKD3sxN3lCirNKgZfrf5hB+aGdEuYVNUQ2dtAuTIk2+WMG87V8MBIzaBQzrdDDVqBDPuIE0cUy5rCC0MMq5lAqQR9hKmRcPoNu0ZF0EN0sYs7JBAyc+UwNsUJYd7nGO2zUGr4CTL9MqMGu8KIaYB43C2yVJPq4h8kpDAaoYv6kS3U4jKvfaGELeUyVfoXDT4C5wAatg8cfuHqbS4A54/K8UgTMd/WnNjuckyqAKdCj8DhArdO0NFilQ8xxhyiq7JMbRqk1GXAEuDshV3hMUesvXkoo6CKe3NHJArUqfEln7KBrdCgaMnVJcIsPa6OcczKKjk6mqFfkFH20RAi6SIfiweMkjS0xwTBvEFaVE3hKAvspEleBfUoOvTGfOH+mJ40X6ctEkaNfaWEn56kQVoVz9CltZDhCjhJBSuR4l4weHdrZwzBjzJFniTJlbpNnljGyDNLW/BmlqelxdR++AoGbDB4jjAAAAABJRU5ErkJggg==`,path:`PlatformIndicators/Web.png`
    },mobile:{
      url:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAAXVBMVEUAAAAwMDgwMDUwMDUuMDYwMDYvMTcvMTYvMTYwMDYwMDUvMTYwMjUvMTUvMjYvMTUuMDUuMDQvMDUtMTUwMDgvMDUwMDAtMDYuMDYwMDAtMDUvMDYuMDUtMDcpMTo5aAq8AAAAH3RSTlMAIGBvf1C//89fMN9g75+/j3+fP0C/IFBfMGDPb08fcZ9WCgAAAMNJREFUeAHt2YWNxQAMg2EX/fiVud1/zBuhSaRjfwv8UsQx5J9L0iw/VySIyUoaXa7wu93pcE/g9KDTFS4F+amF5Em3ZwK7FwPeMEsYcoNVxZAaViX5uTd6MuQJKwY5A01u9goFWph1fyKggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACn/l9d/t3gU/fcEqG9LDKGVLB6saQAZ97owZ2w5NuzwEOKd1G4FMLE5wG36Y/w29ZadRviBn2/Nw2HfjTPgD3/UVA1TCAGgAAAABJRU5ErkJggg==`,path:`PlatformIndicators/Mobile.png`
    },embedded:{
      url:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAk1BMVEUAAAC3u7+4ur+5vL+5u765u7+6vL+2ub+3v7+6u7+5vL66v7+6vL65u761ur+4u765vL+3t7+6u765u7+9vb23t7+7vb+6u766ur+5ur6/v7+vv7+9vcW1tb+5u727u763ur25vL+6vL+3ub24ur+5u7+4vL+5ur66ur64ur25vL+6u764ur24u722uby5u76vr7/eehxsAAAAMXRSTlMAQJ/f/8+fUCC/3zDv7zC/UEDvfx8gf88w3xAQHzCAT2Bfb4Bvj5/PP6+vv59wUM8QEONx+AAAAWZJREFUeAHt1dWa6zAMBOA5PSqzs2Vmhvd/uWWcVFHqr5f+r+3JRqtJ8UhBEAT/Mv8lpWwuD02hKHcpFXBTuSJ3qtZwQ0HPUVULiCuJhzpiGuKlCZaTL3gnxEVPaLWdkAxYJznIdfGmy0k9MEkOivChLQSkbwS18KElZEBBLSMIX4QMuRxaEJ0vCBndCkJMbEZjIRO6MTWCqjWlRjO6MTeCpLoooDWuCFvSjcgK0pYzohsrM0hZzhXdWJtBynJyR4rGv19dzrp3EC3nhoJKZpCynNxalzqIlrPKU7WDlOXUym8H0XIOufy+htxZX9tHBU24/L5mXH5fSy6/r4jL/8sOidYJv2x7fu0k84SgIn/Qmb50dT2oB6YXk+tf4hElWuuPdeaIlCFx/fkLeM+Q1Ferw3RQZ9SmP8jQlR9H/NZ3tKmG08+sW/SMnrxzZ6Qy/TrfBWkdL+Lq0RUptaYHJyU+HwRB4O0FjTMnvIkvoBQAAAAASUVORK5CYII=`,path:`PlatformIndicators/Console.png`
    },vr:{
      url:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAANlBMVEVMaXHv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hs7PTu7vHv7/Hv7/Hv7/Hv7/Hv7/Hv7/Hv7/EEUZf/AAAAEXRSTlMAzGV4UNr78OcJFDufKb6ri3Gd0SEAAAHQSURBVFjD7VbHdsQgDDRNiOby/z+bjY0N2LRk95C8xxwNHo0KkqZpYGBg4PMwbBa4ZYFiZqaPRVGxNSCoavPwJs0ujLbk2K0TtipKz1s3Zl3RE/PILGKmsqbLL8JcwZ5y9LJmi3E+k8Ib1UH8xcI95Utnaeb2TAnmbzLP01NsnilfBEcBCW9FVXWpwzvxrGYiE785ASC1p2DO3M5xlWty5ZREyrEmKlQK0Tedweu1npUdNPxDVBrlHe5bIHQQue1m/YVIEKjIGKmGG7ZbPKYpqnsMnsGqqxUQNSzpP8WdJoSaNUop7nwFInZF600ijT0F3kE06dXS6RNEXfh7ROI/EMG7RPAM2++I8D48wqefZe0cJy74Bo+HaixBJPbRLXX0k5ueDenWgtzVYojLz670edNL55y2wSgPQPOtFhPbirPlKYlDPOyBPwUtjD8auzr6GwYXDKRrA4RAucMFmR0PvuXjeZ3K+wIiT++MD8Wa32n8KSxc67ArSOYcOzln6rTmi5eKhWbMIbMGyV2gkZkjKE4ZVr6cM1Lp6qxslN6ZoDodeLoVi6igTbqlYmOJ0muIBrIku4oFK7Ix9I7atAQ2SWym1F5HEjB3NDAwMPAuvgCPRUw2yKsaYwAAAABJRU5ErkJggg==`,path:`PlatformIndicators/VR.png`
    }
  };
  function f({
    platform:t,color:r,iconSize:i=16
  }){
    var a=d[t];
    return a?(0,n.jsx)(revenge.react.ReactNative.View,{
      children:(0,n.jsx)(revenge.react.ReactNative.Image,{
        style:{
          height:i,width:i,tintColor:r
        },source:{
          uri:a.url,width:i,height:i,path:a.path,allowIconTheming:!0
        }
      })
    }):(0,n.jsx)(revenge.react.ReactNative.View,{
      children:(0,n.jsx)(revenge.react.ReactNative.View,{
        style:{
          width:i,height:i,borderRadius:100,backgroundColor:r
        }
      })
    })
  }var p,m=0,h=null,g;
  function _(){
    return h||(h=setTimeout(function(){
      return m=0,h=null
    },5e3)),(!p||m===0)&&(p=revenge.discord.flux.Stores.PresenceStore?.getState?.()),m=(m+1)%20,p
  }function v(t){
    if(g??(g=revenge.discord.flux.Stores.UserStore?.getCurrentUser?.()?.id),t===g){
      var n=revenge.discord.flux.Stores.SessionsStore?.getSessions?.()??{
      };
      return Object.values(n).reduce(function(t,n){
        return n?.clientInfo?.client&&n.clientInfo.client!==`unknown`&&(t[n.clientInfo.client]=n.status),t
      },{
      })
    }return _()?.clientStatuses?.[t]
  }function y({
    userId:t,size:r=16
  }){
    var i=revenge.utils.react.useReRender();
    revenge.react.React.useEffect(function(){
      return revenge.discord.flux.onFluxEventDispatched(`PRESENCE_UPDATES`,function(t){
        return i(),t
      })
    },[i]);
    var a=v(t)??{
    };
    return(0,n.jsx)(n.Fragment,{
      children:Object.keys(a).map(function(t){
        return(0,n.jsx)(f,{
          platform:t,color:u(a[t],o.cache?.fallbackColors??!1),iconSize:r
        },t)
      })
    })
  }var b={
    walkable:new Set([`props`,`children`])
  },x=function(t){
    return t?.props?.user?.id!==void 0
  };
  function S(t){
    try{
      t()
    }catch{
    }
  }return t.default=plugin({
    async start({
      cleanup:t
    }){
      await o.get(),t(revenge.modules.finders.getModules(i(`ChannelHeader`),function(r){
        var i=a(r);
        i&&t(revenge.patcher.after(i.parent,i.key,function(r){
          return S(function(){
            o.cache?.dmTopBar&&r?.type?.type?.name===`PrivateChannelHeader`&&t(revenge.patcher.after(r.type,`type`,function(r){
              return S(function(){
                var i=revenge.utils.tree.findInTree(r,x,b)?.props?.user?.id;
                if(i){
                  var a=revenge.utils.tree.findInTree(r,function(t){
                    return t?.key===`DMTabsV2HeaderIcons`
                  },b);
                  if(a){
                    a.props.children=(0,n.jsx)(y,{
                      userId:i
                    });
                    return
                  }var o=(r.props?.children)?.props?.children?.props?.children?.[1];
                  if(o&&typeof o.type==`function`){
                    var s=revenge.patcher.after(o,`type`,function(t){
                      return s(),S(function(){
                        revenge.utils.tree.findInTree(t,function(t){
                          return t?.key===`DMTabsV2Header-v2`
                        },b)||t.props.children[0]?.props?.children?.push((0,n.jsx)(y,{
                          userId:i
                        },`DMTabsV2Header-v2`))
                      }),t
                    });
                    t(s)
                  }
                }
              }),r
            }))
          }),r
        }))
      })),t(revenge.modules.finders.getModules(i(`UserProfileContent`),function(r){
        var i=a(r);
        i&&t(revenge.patcher.after(i.parent,i.key,function(r){
          return S(function(){
            var i=revenge.utils.tree.findInTree(r,function(t){
              return t?.type?.name===`PrimaryInfo`
            },b);
            i&&t(revenge.patcher.after(i,`type`,function(r){
              return S(function(){
                r?.type?.name===`UserProfilePrimaryInfo`&&t(revenge.patcher.after(r,`type`,function(r){
                  return S(function(){
                    var i=revenge.utils.tree.findInTree(r,function(t){
                      return t?.type?.name===`DisplayName`
                    },b);
                    i&&t(revenge.patcher.after(i,`type`,function(t){
                      return S(function(){
                        var r=i.props?.user?.id;
                        !r||!o.cache?.profileUsername||t?.props?.children?.push((0,n.jsx)(y,{
                          userId:r
                        },`UserProfileIcons`))
                      }),t
                    }))
                  }),r
                }))
              }),r
            }))
          }),r
        }))
      })),t(revenge.modules.finders.getModules(revenge.modules.finders.filters.withProps(`DisplayName`),function(r){
        t(revenge.patcher.instead(r,`DisplayName`,function(t,r){
          var i=r(...t);
          return S(function(){
            var r=t[0]?.user;
            !r?.id||!i||!o.cache?.profileUsername||i.props?.children?.props?.children?.[0]?.props?.children?.push((0,n.jsx)(y,{
              userId:r.id
            },`DisplayNameIcons`))
          }),i
        }))
      })),t(revenge.modules.finders.getModules(i(`Status`),function(n){
        var r=a(n);
        r&&t(revenge.patcher.before(r.parent,r.key,function(t){
          return S(function(){
            o.cache?.removeDefaultMobile&&t[0]&&(t[0].isMobileOnline=!1)
          }),t
        }))
      })),t(revenge.modules.finders.getModules(i(`UserRow`),function(r){
        var i=a(r);
        if(i){
          var s=!1;
          t(revenge.patcher.instead(i.parent,i.key,function([r],i){
            var a=i(r);
            return S(function(){
              if(o.cache?.userList){
                var i=r?.user;
                i?.id&&(revenge.utils.tree.findInTree(a?.props?.label,function(t){
                  return t?.key===`TabsV2MemberListStatusIconsView`
                },b)||(a.props.label=(0,n.jsxs)(revenge.react.ReactNative.View,{
                  style:{
                    justifyContent:o.cache?.oldUserListIcons?`space-between`:`flex-start`,flexDirection:`row`,alignItems:`center`
                  },children:[a.props.label,(0,n.jsx)(revenge.react.ReactNative.View,{
                    style:{
                      flexDirection:`row`
                    },children:(0,n.jsx)(y,{
                      userId:i.id
                    })
                  },`TabsV2MemberListStatusIconsView`)]
                },`TabsV2MemberListStatusIconsView`),!s&&a.props.icon?.type&&(t(revenge.patcher.before(a.props.icon,`type`,function([t]){
                  return o.cache?.removeDefaultMobile&&t&&(t.isMobileOnline=!1),[t]
                })),s=!0)))
              }
            }),a
          }))
        }
      },{
        max:1/0
      })),t(revenge.modules.finders.getModules(i(`MessagesItemChannelContent`),function(r){
        var i=a(r);
        i&&t(revenge.patcher.instead(i.parent,i.key,function([t],r){
          var i=r(t);
          return S(function(){
            if(o.cache?.userList){
              var r=t?.channel;
              if(r?.recipients?.length===1){
                var a=r.recipients[0];
                revenge.utils.tree.findInTree(i,function(t){
                  return t?.props?.children?.[0]?.props?.variant===`redesign/channel-title/semibold`
                },b)?.props?.children?.push((0,n.jsx)(revenge.react.ReactNative.View,{
                  style:{
                    flexDirection:`row`
                  },children:(0,n.jsx)(y,{
                    userId:a
                  })
                },`TabsV2RedesignDMListIcons`))
              }
            }
          }),i
        }))
      }))
    },SettingsComponent:s
  }),t
})({
},revenge.react.ReactJSXRuntime);